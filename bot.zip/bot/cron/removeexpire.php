<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Application;
use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Repositories\PanelRepository;
use App\Services\Panels\XuiPanelService;

new Application();

$db = Database::getInstance();
if (!$db) {
    exit("DB Connection Failed\n");
}

$invoiceRepo = new InvoiceRepository($db);
$panelRepo = new PanelRepository($db);

$removalDays = 7; 
$longExpiredInvoices = $invoiceRepo->findLongExpired($removalDays);

$panels = [];

foreach ($longExpiredInvoices as $invoice) {
    $panelId = (int)$invoice['panel_id'];

    if (!isset($panels[$panelId])) {
        $panelInfo = $panelRepo->findById($panelId);
        if (!$panelInfo) continue;
        $panels[$panelId] = new XuiPanelService($panelInfo['api_url'], $panelInfo['username'], $panelInfo['password'], $panelInfo['login_path']);
    }
    
    $panelService = $panels[$panelId];
    $success = $panelService->deleteClient($invoice['panel_service_username']);

    if ($success) {
        $invoiceRepo->updateStatus($invoice['id'], 'deleted');
        echo "Successfully deleted user {$invoice['panel_service_username']}\n";
    } else {
        echo "Failed to delete user {$invoice['panel_service_username']}\n";
    }
    
    usleep(100000); 
}

echo "Cron job for removing expired users completed.\n";