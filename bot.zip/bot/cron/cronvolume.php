<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Application;
use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Repositories\PanelRepository;
use App\Services\TelegramService;
use App\Services\LangService;
use App\Services\Panels\XuiPanelService;

new Application();

$db = Database::getInstance();
if (!$db) {
    exit("DB Connection Failed\n");
}

$invoiceRepo = new InvoiceRepository($db);
$panelRepo = new PanelRepository($db);
$telegram = new TelegramService($_ENV['BOT_TOKEN']);

$activeInvoices = $invoiceRepo->findAllActiveToWarn();
$panels = [];
$warningThresholdBytes = 1 * 1024 * 1024 * 1024; 

foreach ($activeInvoices as $invoice) {
    $panelId = (int)$invoice['panel_id'];

    if (!isset($panels[$panelId])) {
        $panelInfo = $panelRepo->findById($panelId);
        if (!$panelInfo) continue;
        $panels[$panelId] = new XuiPanelService($panelInfo['api_url'], $panelInfo['username'], $panelInfo['password'], $panelInfo['login_path']);
    }
    
    $panelService = $panels[$panelId];
    $liveData = $panelService->getClient($invoice['panel_service_username']);

    if (!$liveData || $liveData['total'] == 0) {
        continue;
    }

    $totalBytes = $liveData['total'];
    $usedBytes = $liveData['up'] + $liveData['down'];
    $remainingBytes = $totalBytes - $usedBytes;

    if ($remainingBytes > 0 && $remainingBytes <= $warningThresholdBytes) {
        $remainingGB = number_format($remainingBytes / (1024**3), 2);
        $message = LangService::get('volume_warning_message', [
            'username' => $invoice['panel_service_username'],
            'volume' => $remainingGB
        ]);
    
        $keyboard = ['inline_keyboard' => [[['text' => '➕ خرید حجم اضافه', 'callback_data' => 'add_data_' . $invoice['id']]]]];
        
        $telegram->sendMessage((int)$invoice['user_id'], $message, $keyboard);
        
        $invoiceRepo->updateVolumeWarningSent($invoice['id']);
    }
}

echo "Cron job for volume warnings completed.\n";