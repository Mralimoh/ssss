<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Application;
use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Services\TelegramService;
use App\Services\LangService;

new Application();

$db = Database::getInstance();
if (!$db) {
    exit("DB Connection Failed\n");
}

$invoiceRepo = new InvoiceRepository($db);
$telegram = new TelegramService($_ENV['BOT_TOKEN']);

$warningDays = 3;
$targetTimestamp = time() + ($warningDays * 86400);

$expiringInvoices = $invoiceRepo->findExpiringSoon($warningDays);

foreach ($expiringInvoices as $invoice) {
    $expiresAt = strtotime($invoice['expires_at']);
    $remainingDays = ceil(($expiresAt - time()) / 86400);

    if ($remainingDays <= 0) continue;

    $message = LangService::get('renewal_warning_message', [
        'username' => $invoice['panel_service_username'],
        'days' => $remainingDays
    ]);
    
    $keyboard = [
        'inline_keyboard' => [
            [['text' => '🔄 تمدید سرویس', 'callback_data' => 'renew_service_' . $invoice['id']]]
        ]
    ];
    
    $telegram->sendMessage((int)$invoice['user_id'], $message, $keyboard);
    
    $invoiceRepo->updateWarningSent($invoice['id']);
}

echo "Expiration warning cron job completed.\n";