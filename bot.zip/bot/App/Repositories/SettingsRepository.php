<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class SettingsRepository
{
    private PDO $db;
    private static ?array $settingsCache = null;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function get(string $key, string $default = ''): string
    {
        $settings = $this->getAll();
        return $settings[$key] ?? $default;
    }

    public function getAll(): array
    {
        if (self::$settingsCache === null) {
            $stmt = $this->db->query("SELECT `key`, `value` FROM `settings`");
            self::$settingsCache = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        }

        return self::$settingsCache;
    }

    public function set(string $key, string $value): bool
    {
        $sql = "INSERT INTO `settings` (`key`, `value`) VALUES (:key, :value)
                ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)";
        $stmt = $this->db->prepare($sql);
        
        $success = $stmt->execute(['key' => $key, 'value' => $value]);

        if ($success) {
            self::$settingsCache = null;
        }

        return $success;
    }
}