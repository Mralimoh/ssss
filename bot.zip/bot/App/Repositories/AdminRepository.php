<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class AdminRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function isAdmin(int $userId): bool
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `admins` WHERE `user_id` = :user_id");
        $stmt->execute(['user_id' => $userId]);
        return (bool) $stmt->fetchColumn();
    }

    public function add(int $userId, string $role = 'admin'): bool
    {
        $stmt = $this->db->prepare("INSERT IGNORE INTO `admins` (user_id, role) VALUES (:user_id, :role)");
        return $stmt->execute(['user_id' => $userId, 'role' => $role]);
    }
    
    public function remove(int $userId): bool
    {
        $stmt = $this->db->prepare("DELETE FROM `admins` WHERE `user_id` = :user_id");
        return $stmt->execute(['user_id' => $userId]);
    }

    public function findAll(): array
    {
        return $this->db->query("SELECT * FROM `admins`")->fetchAll(PDO::FETCH_ASSOC);
    }
}