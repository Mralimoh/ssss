<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class ProductRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function create(array $data): bool
    {
        $sql = "INSERT INTO `products` (panel_id, category_id, name, price, data_limit_gb, duration_days, is_test_product, is_active)
                VALUES (:panel_id, :category_id, :name, :price, :data_limit_gb, :duration_days, :is_test_product, 1)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function findAll(): array
    {
        $sql = "SELECT p.*, pn.name as panel_name FROM `products` p
                LEFT JOIN `panels` pn ON p.panel_id = pn.id
                ORDER BY p.id DESC";
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findActiveByPanelId(int $panelId): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM `products` WHERE `panel_id` = :panel_id AND `is_active` = 1 AND `is_test_product` = 0 ORDER BY `price` ASC"
        );
        $stmt->execute(['panel_id' => $panelId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getActiveTestProducts(): array
    {
        $stmt = $this->db->query(
            "SELECT * FROM `products` WHERE `is_active` = 1 AND `is_test_product` = 1"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM `products` WHERE `id` = :id");
        return $stmt->execute(['id' => $id]);
    }
}