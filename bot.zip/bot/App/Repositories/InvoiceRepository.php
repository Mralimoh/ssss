<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class InvoiceRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function create(array $data): ?int
    {
        $sql = "INSERT INTO `invoice` (user_id, product_id, panel_service_username, status, expires_at, created_at)
                VALUES (:user_id, :product_id, :username, :status, :expires_at, NOW())";
        $stmt = $this->db->prepare($sql);
        
        if ($stmt->execute($data)) {
            return (int) $this->db->lastInsertId();
        }
        
        return null;
    }

    public function findById(int $invoiceId, int $chatId): array|false
    {
        $stmt = $this->db->prepare("SELECT * FROM `invoice` WHERE `id` = :id AND `user_id` = :user_id");
        $stmt->execute(['id' => $invoiceId, 'user_id' => $chatId]);
        return $stmt->fetch();
    }

    public function findActiveByUser(int $chatId, int $page = 1, int $limit = 5): array
    {
        $offset = ($page - 1) * $limit;
        $stmt = $this->db->prepare(
            "SELECT i.*, p.name as product_name FROM `invoice` i
             JOIN `products` p ON i.product_id = p.id
             WHERE i.user_id = :user_id AND i.status = 'active'
             ORDER BY i.created_at DESC
             LIMIT :limit OFFSET :offset"
        );
        $stmt->bindValue(':user_id', $chatId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function countAllActive(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM `invoice` WHERE `status` = 'active'")->fetchColumn();
    }
    
    public function countActiveForUser(int $chatId): int
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `invoice` WHERE `user_id` = :user_id AND `status` = 'active'");
        $stmt->execute(['user_id' => $chatId]);
        return (int) $stmt->fetchColumn();
    }

    public function updateStatus(int $invoiceId, string $status): bool
    {
        $stmt = $this->db->prepare("UPDATE `invoice` SET `status` = :status WHERE `id` = :id");
        return $stmt->execute(['status' => $status, 'id' => $invoiceId]);
    }
}