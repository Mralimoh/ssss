<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class UserRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function find(int $chatId): array|false
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute(['id' => $chatId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && !empty($user['step'])) {
            $user['step'] = json_decode($user['step'], true);
        }

        return $user;
    }

    public function create(int $chatId, string $firstName, ?string $username, ?int $referrerId = null): array
    {
        $initialStep = json_encode(['start']);
        $sql = "INSERT INTO users (id, first_name, username, step, referrer_id, created_at)
                VALUES (:id, :first_name, :username, :step, :referrer_id, NOW())";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'id' => $chatId,
            'first_name' => $firstName,
            'username' => $username,
            'step' => $initialStep,
            'referrer_id' => $referrerId,
        ]);

        return $this->find($chatId);
    }

    public function updateStep(int $chatId, array $steps): bool
    {
        $stmt = $this->db->prepare("UPDATE `users` SET `step` = :step WHERE `id` = :id");
        return $stmt->execute(['step' => json_encode($steps), 'id' => $chatId]);
    }

    public function addBalance(int $chatId, float $amount): bool
    {
        $stmt = $this->db->prepare("UPDATE `users` SET `balance` = `balance` + :amount WHERE `id` = :id");
        return $stmt->execute(['amount' => $amount, 'id' => $chatId]);
    }

    public function deductBalance(int $chatId, float $amount): bool
    {
        $stmt = $this->db->prepare("UPDATE `users` SET `balance` = `balance` - :amount WHERE `id` = :id AND `balance` >= :amount");
        return $stmt->rowCount() > 0;
    }

    public function useTestAccount(int $chatId): bool
    {
         $stmt = $this->db->prepare("UPDATE `users` SET `test_accounts_left` = `test_accounts_left` - 1 WHERE `id` = :id AND `test_accounts_left` > 0");
         return $stmt->rowCount() > 0;
    }

    public function block(int $chatId): bool
    {
        $stmt = $this->db->prepare("UPDATE `users` SET `status` = 'blocked' WHERE `id` = :id");
        return $stmt->execute(['id' => $chatId]);
    }

    public function unblock(int $chatId): bool
    {
        $stmt = $this->db->prepare("UPDATE `users` SET `status` = 'active' WHERE `id` = :id");
        return $stmt->execute(['id' => $chatId]);
    }

    public function countAll(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM `users`")->fetchColumn();
    }

    public function getAllUserIds(): array
    {
        return $this->db->query("SELECT id FROM `users` WHERE `status` = 'active'")->fetchAll(PDO::FETCH_COLUMN);
    }

    public function countReferrals(int $chatId): int
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `users` WHERE `referrer_id` = :id");
        $stmt->execute(['id' => $chatId]);
        return (int) $stmt->fetchColumn();
    }
}