<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class DataPackRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function findById(int $packId): array|false
    {
        $stmt = $this->db->prepare("SELECT * FROM `data_packs` WHERE `id` = :id AND `is_active` = 1");
        $stmt->execute(['id' => $packId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function findAllActive(): array
    {
        return $this->db->query(
            "SELECT * FROM `data_packs` WHERE `is_active` = 1 ORDER BY `price` ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
}