<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class TransactionRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function createPending(int $userId, float $amount, string $gateway): ?int
    {
        $sql = "INSERT INTO `transactions` (user_id, amount, gateway, status, created_at)
                VALUES (:user_id, :amount, :gateway, 'pending', NOW())";
        $stmt = $this->db->prepare($sql);

        if ($stmt->execute([
            'user_id' => $userId,
            'amount'  => $amount,
            'gateway' => $gateway,
        ])) {
            return (int) $this->db->lastInsertId();
        }

        return null;
    }

    public function findById(int $transactionId): array|false
    {
        $stmt = $this->db->prepare("SELECT * FROM `transactions` WHERE `id` = :id");
        $stmt->execute(['id' => $transactionId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateStatus(int $transactionId, string $status, ?string $refId = null): bool
    {
        $sql = "UPDATE `transactions` SET `status` = :status, `ref_id` = :ref_id WHERE `id` = :id";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            'status' => $status,
            'ref_id' => $refId,
            'id'     => $transactionId,
        ]);
    }
}