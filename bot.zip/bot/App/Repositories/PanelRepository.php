<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class PanelRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function findById(int $id): array|false
    {
        $stmt = $this->db->prepare("SELECT * FROM `panels` WHERE `id` = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function findAll(): array
    {
        return $this->db->query("SELECT * FROM `panels` ORDER BY `id` ASC")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(array $data): bool
    {
        $sql = "INSERT INTO `panels` (name, type, api_url, username, password, login_path)
                VALUES (:name, :type, :api_url, :username, :password, :login_path)";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            'name' => $data['name'],
            'type' => $data['type'],
            'api_url' => $data['api_url'],
            'username' => $data['username'],
            'password' => $data['password'],
            'login_path' => $data['login_path'] ?? null,
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM `panels` WHERE `id` = :id");
        return $stmt->execute(['id' => $id]);
    }
}