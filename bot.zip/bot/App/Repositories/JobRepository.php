<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

class JobRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function create(string $jobType, string $payload): bool
    {
        $sql = "INSERT INTO `jobs` (job_type, payload, status, created_at)
                VALUES (:job_type, :payload, 'pending', NOW())";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            'job_type' => $jobType,
            'payload'  => $payload,
        ]);
    }

    public function getNextPendingJob(): array|false
    {
        $sql = "SELECT * FROM `jobs` WHERE `status` = 'pending' ORDER BY `id` ASC LIMIT 1 FOR UPDATE";
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateStatus(int $jobId, string $status): bool
    {
        $sql = "UPDATE `jobs` SET `status` = :status WHERE `id` = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['status' => $status, 'id' => $jobId]);
    }
}