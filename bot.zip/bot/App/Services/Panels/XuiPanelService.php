<?php

declare(strict_types=1);

namespace App\Services\Panels;

class XuiPanelService implements PanelServiceInterface
{
    private string $apiUrl;
    private string $username;
    private string $password;
    private ?string $loginPath;
    private ?string $sessionCookie = null;

    public function __construct(string $apiUrl, string $username, string $password, ?string $loginPath = null)
    {
        $this->apiUrl = rtrim($apiUrl, '/');
        $this->username = $username;
        $this->password = $password;
        $this->loginPath = $loginPath ? '/' . ltrim($loginPath, '/') : '';
    }

    private function login(): bool
    {
        if ($this->sessionCookie !== null) {
            return true;
        }

        $loginUrl = $this->apiUrl . '/login' . $this->loginPath;
        $postData = http_build_query(['username' => $this->username, 'password' => $this->password]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $loginUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || $response === false) {
            return false;
        }

        preg_match('/^Set-Cookie:\s*([^;]*)/mi', $response, $matches);
        if (isset($matches[1])) {
            $this->sessionCookie = $matches[1];
            return true;
        }

        return false;
    }

    private function getClientByEmail(string $email): ?array
    {
        if (!$this->login()) return null;

        $ch = curl_init($this->apiUrl . '/panel/api/inbounds/list');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Cookie: ' . $this->sessionCookie, 'Accept: application/json']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);
        
        $inbounds = json_decode($response, true);

        if (!$inbounds || !($inbounds['success'] ?? false) || !is_array($inbounds['obj'])) {
            return null;
        }

        foreach ($inbounds['obj'] as $inbound) {
            $clientSettings = json_decode($inbound['settings'], true);
            if (isset($clientSettings['clients'])) {
                foreach ($clientSettings['clients'] as $client) {
                    if (isset($client['email']) && $client['email'] === $email) {
                        return ['inboundId' => $inbound['id'], 'client' => $client];
                    }
                }
            }
        }

        return null;
    }

    public function getClient(string $username): ?array
    {
        if (!$this->login()) return null;

        $url = $this->apiUrl . '/panel/api/inbounds/getClientTraffics/' . urlencode($username);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Cookie: ' . $this->sessionCookie, 'Accept: application/json']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return ($result && ($result['success'] ?? false) && isset($result['obj'])) ? $result['obj'] : null;
    }
    
    public function addClient(array $data): ?array
    {
        if (!$this->login()) return null;

        $clientSettings = [
            'clients' => [
                [
                    'id' => $this->generateUuid(),
                    'email' => $data['email'],
                    'totalGB' => ($data['total_gb'] ?? 0) * 1024 * 1024 * 1024,
                    'expiryTime' => $data['expiry_time'] ?? 0,
                    'enable' => true,
                    'onHold' => $data['on_hold'] ?? false,
                ]
            ]
        ];
        
        $postData = json_encode([
            'id' => $data['inbound_id'],
            'settings' => json_encode($clientSettings)
        ]);

        $ch = curl_init($this->apiUrl . '/panel/api/inbounds/addClient');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Cookie: ' . $this->sessionCookie]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return ($result && ($result['success'] ?? false)) ? ($result['obj'] ?? true) : null;
    }

    public function updateClient(string $username, array $newSettings): bool
    {
        $clientInfo = $this->getClientByEmail($username);
        if ($clientInfo === null || !$this->login()) return false;

        $inboundId = $clientInfo['inboundId'];
        $clientUuid = $clientInfo['client']['id'];

        $postData = json_encode([
            'id' => $inboundId,
            'settings' => json_encode(['clients' => [['id' => $clientUuid] + $newSettings]])
        ]);

        $ch = curl_init($this->apiUrl . '/panel/api/inbounds/updateClient/' . $clientUuid);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Cookie: ' . $this->sessionCookie]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return $result && ($result['success'] ?? false);
    }

    public function deleteClient(string $username): bool
    {
        $clientInfo = $this->getClientByEmail($username);
        if ($clientInfo === null || !$this->login()) return false;

        $inboundId = $clientInfo['inboundId'];
        $clientUuid = $clientInfo['client']['id'];

        $url = $this->apiUrl . '/panel/api/inbounds/' . $inboundId . '/delClient/' . $clientUuid;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Cookie: ' . $this->sessionCookie, 'Accept: application/json']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return $result && ($result['success'] ?? false);
    }

    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}