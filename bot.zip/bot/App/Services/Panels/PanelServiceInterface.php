<?php

declare(strict_types=1);

namespace App\Services\Panels;

interface PanelServiceInterface
{
    public function addClient(array $data): ?array;

    public function getClient(string $username): ?array;

    public function updateClient(string $username, array $newSettings): bool;

    public function deleteClient(string $username): bool;
}