<?php

declare(strict_types=1);

namespace App\Services;

use CURLFile;

class TelegramService
{
    private string $botToken;
    private string $apiUrl = 'https://api.telegram.org/bot';

    public function __construct(string $botToken)
    {
        $this->botToken = $botToken;
    }

    public function sendMessage(int $chatId, string $text, ?array $keyboard = null, string $parseMode = 'Markdown'): ?array
    {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => $parseMode,
        ];

        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }

        return $this->sendRequest('sendMessage', $data);
    }

    public function editMessageText(int $chatId, int $messageId, string $text, ?array $keyboard = null, string $parseMode = 'Markdown'): ?array
    {
        $data = [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => $parseMode,
        ];

        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }

        return $this->sendRequest('editMessageText', $data);
    }

    public function sendPhoto(int $chatId, string $photoPath, string $caption = '', ?array $keyboard = null, string $parseMode = 'Markdown'): ?array
    {
        $data = [
            'chat_id' => $chatId,
            'photo'   => new CURLFile(realpath($photoPath)),
            'caption' => $caption,
            'parse_mode' => $parseMode,
        ];

        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }

        return $this->sendRequest('sendPhoto', $data);
    }

    public function answerCallbackQuery(string $callbackQueryId, ?string $text = null, bool $showAlert = false): ?array
    {
        $data = [
            'callback_query_id' => $callbackQueryId,
            'show_alert' => $showAlert,
        ];

        if ($text) {
            $data['text'] = $text;
        }

        return $this->sendRequest('answerCallbackQuery', $data);
    }

    private function sendRequest(string $method, array $data): ?array
    {
        $url = $this->apiUrl . $this->botToken . '/' . $method;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        curl_close($ch);

        return $response ? json_decode($response, true) : null;
    }
}