<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Repositories\SettingsRepository;

class LangService
{
    public static function get(string $key, array $placeholders = [], string $default = ''): string
    {
        $db = Database::getInstance();
        if (!$db) {
            return vsprintf($default, $placeholders);
        }

        $settingsRepo = new SettingsRepository($db);
        $template = $settingsRepo->get($key, $default);

        foreach ($placeholders as $placeholder => $value) {
            $template = str_replace('{' . $placeholder . '}', (string) $value, $template);
        }

        return $template;
    }
}