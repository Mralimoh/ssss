<?php

declare(strict_types=1);

namespace App\Core;

use Dotenv\Dotenv;

class Application
{
    public function __construct()
    {
        if (file_exists(__DIR__ . '/../../.env')) {
            $dotenv = Dotenv::createImmutable(__DIR__ . '/../../');
            $dotenv->load();
        }
    }

    public function run(): void
    {
        $update = json_decode(file_get_contents('php://input'), true);

        if (!$update) {
            return;
        }

        $router = new Router($update);
        $router->handle();
    }
}