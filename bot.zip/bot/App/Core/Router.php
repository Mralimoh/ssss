<?php

declare(strict_types=1);

namespace App\Core;

use App\Repositories\AdminRepository;
use App\Repositories\SettingsRepository;
use App\Controllers\StartController;
use App\Controllers\Admin\DashboardController;

class Router
{
    protected array $update;
    protected ?int $chatId;
    protected ?string $messageText;
    protected ?string $callbackData;
    protected object $db;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->db = Database::getInstance();
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'] ?? null;
        $this->messageText = $update['message']['text'] ?? null;
        $this->callbackData = $update['callback_query']['data'] ?? null;
    }

    public function handle(): void
    {
        if (!$this->chatId) {
            return;
        }

        $controllerClass = $this->determineController();

        if ($controllerClass) {
            $this->routeToController($controllerClass);
        }
    }
    
    private function determineController(): ?string
    {
        $settingsRepo = new SettingsRepository($this->db);
        $settings = $settingsRepo->getAll();

        $textCommandMap = [
            '/start' => StartController::class,
            '/panel' => DashboardController::class,
        ];

        if ($this->messageText && isset($textCommandMap[$this->messageText])) {
            return $textCommandMap[$this->messageText];
        }
        
        return null;
    }

    private function routeToController(string $controllerClass): void
    {
        if (str_contains($controllerClass, 'Admin\\')) {
            $adminRepo = new AdminRepository($this->db);
            if (!$adminRepo->isAdmin($this->chatId)) {
                return;
            }
        }
        
        $controller = new $controllerClass($this->update);
        $controller->handle();
    }
}