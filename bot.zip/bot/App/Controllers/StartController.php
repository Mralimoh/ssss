<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\UserRepository;
use App\Repositories\SettingsRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class StartController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private UserRepository $userRepo;
    private SettingsRepository $settingsRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'];
        $this->messageText = $update['message']['text'] ?? null;

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->settingsRepo = new SettingsRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $user = $this->userRepo->find($this->chatId);

        if (!$user) {
            $referrerId = null;
            $parts = explode(' ', $this->messageText);
            if (isset($parts[1]) && str_starts_with($parts[1], 'ref_')) {
                $potentialReferrerId = (int) str_replace('ref_', '', $parts[1]);
                if ($potentialReferrerId !== $this->chatId) {
                    $referrerId = $potentialReferrerId;
                }
            }

            $this->userRepo->create(
                $this->chatId,
                $this->update['message']['from']['first_name'],
                $this->update['message']['from']['username'] ?? null,
                $referrerId
            );
            
            if ($referrerId) {
                $joinBonus = (float) $this->settingsRepo->get('referral_join_bonus', '0');
                if ($joinBonus > 0) {
                    $this->userRepo->addBalance($referrerId, $joinBonus);
                }
            }
        }

        $welcomeMessage = $this->settingsRepo->get('welcome_message', 'Welcome!');
        
        $mainKeyboard = [
            'keyboard' => [
                [
                    ['text' => $this->settingsRepo->get('btn_buy_subscription', 'خرید اشتراک')],
                    ['text' => $this->settingsRepo->get('btn_test_account', 'اکانت تست')]
                ],
                [
                    ['text' => $this->settingsRepo->get('btn_my_subscriptions', 'اشتراک های من')],
                    ['text' => $this->settingsRepo->get('btn_add_balance', 'افزایش موجودی')]
                ],
                [
                    ['text' => $this->settingsRepo->get('btn_profile', 'مشخصات کاربری')],
                    ['text' => $this->settingsRepo->get('btn_referrals', 'زیرمجموعه گیری')]
                ],
                [['text' => $this->settingsRepo->get('btn_support', 'پشتیبانی')]]
            ],
            'resize_keyboard' => true
        ];

        $this->telegram->sendMessage($this->chatId, $welcomeMessage, $mainKeyboard);
    }
}