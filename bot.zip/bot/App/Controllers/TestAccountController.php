<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Repositories\PanelRepository;
use App\Repositories\ProductRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\Panels\XuiPanelService;
use App\Services\TelegramService;

class TestAccountController
{
    private array $update;
    private int $chatId;
    private ?string $callbackData;
    private UserRepository $userRepo;
    private ProductRepository $productRepo;
    private InvoiceRepository $invoiceRepo;
    private PanelRepository $panelRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->productRepo = new ProductRepository($db);
        $this->invoiceRepo = new InvoiceRepository($db);
        $this->panelRepo = new PanelRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        if ($this->callbackData) {
            $this->handleCallback();
        } else {
            $this->showTestProducts();
        }
    }

    private function handleCallback(): void
    {
        $callbackQueryId = $this->update['callback_query']['id'];
        $this->telegram->answerCallbackQuery($callbackQueryId);

        if (str_starts_with($this->callbackData, 'get_test_')) {
            $productId = (int) str_replace('get_test_', '', $this->callbackData);
            $this->createTestService($productId);
        }
    }

    private function showTestProducts(): void
    {
        $user = $this->userRepo->find($this->chatId);
        if (!$user || $user['test_accounts_left'] <= 0) {
            $this->telegram->sendMessage($this->chatId, LangService::get('test_account_limit_reached'));
            return;
        }

        $testProducts = $this->productRepo->getActiveTestProducts();
        if (empty($testProducts)) {
            $this->telegram->sendMessage($this->chatId, LangService::get('no_test_account_available'));
            return;
        }

        $message = LangService::get('select_test_plan', 'Please choose your desired test plan:');
        $keyboard = ['inline_keyboard' => []];
        foreach ($testProducts as $product) {
            $keyboard['inline_keyboard'][] = [['text' => $product['name'], 'callback_data' => 'get_test_' . $product['id']]];
        }

        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }

    private function createTestService(int $productId): void
    {
        if (!$this->userRepo->useTestAccount($this->chatId)) {
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], LangService::get('test_account_limit_reached'));
            return;
        }

        $product = $this->productRepo->findById($productId);
        $panel = $this->panelRepo->findById((int)$product['panel_id']);
        if (!$product || !$panel) {
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], LangService::get('error_creating_test_account'));
            return;
        }

        $email = 'test_' . $this->chatId . '_' . time();
        $expiryTime = time() + ($product['duration_days'] * 86400);
        
        $panelService = new XuiPanelService($panel['api_url'], $panel['username'], $panel['password'], $panel['login_path']);
        
        $clientData = [
            'inbound_id' => $product['inbound_id'],
            'email' => $email,
            'total_gb' => $product['data_limit_gb'],
            'expiry_time' => $expiryTime * 1000,
        ];

        $newUser = $panelService->addClient($clientData);

        if ($newUser) {
            $message = LangService::get('test_account_created_successfully', ['username' => $email]);
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message);
        } else {
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], LangService::get('error_creating_test_account'));
            $this->userRepo->addTestAccountCredit($this->chatId);
        }
    }
}