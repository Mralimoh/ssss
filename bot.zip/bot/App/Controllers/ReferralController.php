<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\UserRepository;
use App\Repositories\SettingsRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class ReferralController
{
    private array $update;
    private int $chatId;
    private UserRepository $userRepo;
    private SettingsRepository $settingsRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'];

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->settingsRepo = new SettingsRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $botUsername = $_ENV['BOT_USERNAME'];
        $referralLink = "https://t.me/{$botUsername}?start=ref_{$this->chatId}";
        
        $referralCount = $this->userRepo->countReferrals($this->chatId);
        $joinBonus = $this->settingsRepo->get('referral_join_bonus', '0');
        $commissionPercent = $this->settingsRepo->get('referral_purchase_commission_percent', '0');
        
        $message = LangService::get('referral_program_details', [
            'referralLink' => '`' . $referralLink . '`',
            'referralCount' => $referralCount,
            'joinBonus' => number_format((float)$joinBonus),
            'commissionPercent' => $commissionPercent,
        ]);
        
        $this->telegram->sendMessage($this->chatId, $message);
    }
}