<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\UserRepository;
use App\Repositories\InvoiceRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class ProfileController
{
    private array $update;
    private int $chatId;
    private UserRepository $userRepo;
    private InvoiceRepository $invoiceRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'];

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->invoiceRepo = new InvoiceRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $user = $this->userRepo->find($this->chatId);

        if (!$user) {
            return;
        }

        $activeServicesCount = $this->invoiceRepo->countActiveForUser($this->chatId);
        $referralCount = $this->userRepo->countReferrals($this->chatId);

        $profileText = LangService::get('user_profile_template', [
            'userId' => $user['id'],
            'firstName' => htmlspecialchars($user['first_name']),
            'balance' => number_format((float)$user['balance']),
            'serviceCount' => $activeServicesCount,
            'referralCount' => $referralCount,
        ]);

        $this->telegram->sendMessage($this->chatId, $profileText);
    }
}