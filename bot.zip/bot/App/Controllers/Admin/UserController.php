<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class UserController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private UserRepository $userRepo;
    private InvoiceRepository $invoiceRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'];
        $this->messageText = $update['message']['text'] ?? null;

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->invoiceRepo = new InvoiceRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $admin = $this->userRepo->find($this->chatId);
        $steps = $admin['step'] ?? ['start'];
        $currentStep = end($steps);

        if ($currentStep === 'admin_awaiting_user_id') {
            if (is_numeric($this->messageText)) {
                array_pop($steps);
                $this->userRepo->updateStep($this->chatId, $steps);
                $this->showUserProfile((int)$this->messageText);
            } else {
                $this->telegram->sendMessage($this->chatId, LangService::get('admin_invalid_user_id_format'));
            }
        } else {
            $this->promptForUserId();
        }
    }

    private function promptForUserId(): void
    {
        $admin = $this->userRepo->find($this->chatId);
        $steps = $admin['step'] ?? ['start'];
        $steps[] = 'admin_awaiting_user_id';
        $this->userRepo->updateStep($this->chatId, $steps);

        $message = LangService::get('admin_prompt_user_id', 'Please enter the User ID to manage:');
        $keyboard = ['inline_keyboard' => [[['text' => '◀️ بازگشت به داشبورد', 'callback_data' => 'admin_dashboard']]]];
        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }

    private function showUserProfile(int $userId): void
    {
        $user = $this->userRepo->find($userId);
        if (!$user) {
            $this->telegram->sendMessage($this->chatId, LangService::get('admin_user_not_found'));
            return;
        }

        $activeServicesCount = $this->invoiceRepo->countActiveForUser($userId);

        $profileText = LangService::get('admin_user_profile_template', [
            'userId'       => $user['id'],
            'firstName'    => htmlspecialchars($user['first_name']),
            'username'     => $user['username'] ? '@' . $user['username'] : 'None',
            'balance'      => number_format((float)$user['balance']),
            'status'       => $user['status'],
            'serviceCount' => $activeServicesCount,
        ]);

        $keyboard = [
            'inline_keyboard' => [
                [['text' => '💰 Add Balance', 'callback_data' => "admin_user_add_balance_{$userId}"]],
                [['text' => '👁️ View Services', 'callback_data' => "admin_user_view_services_{$userId}"]],
                [['text' => 'Block User', 'callback_data' => "admin_user_block_{$userId}"]],
                [['text' => '◀️ Search Another User', 'callback_data' => 'admin_manage_users']]
            ]
        ];

        $this->telegram->sendMessage($this->chatId, $profileText, $keyboard);
    }
}