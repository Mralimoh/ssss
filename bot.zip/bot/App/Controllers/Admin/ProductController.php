<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\DataPackRepository;
use App\Repositories\ProductRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class ProductController
{
    private array $update;
    private int $chatId;
    private ?string $callbackData;
    private ProductRepository $productRepo;
    private DataPackRepository $dataPackRepo;
    private UserRepository $userRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->productRepo = new ProductRepository($db);
        $this->dataPackRepo = new DataPackRepository($db);
        $this->userRepo = new UserRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        if ($this->callbackData) {
            $this->handleCallback();
        } else {
            $this->showMainMenu();
        }
    }
    
    private function handleCallback(): void
    {
        $callbackQueryId = $this->update['callback_query']['id'];
        $this->telegram->answerCallbackQuery($callbackQueryId);
        
        if ($this->callbackData === 'admin_manage_plans') {
            $this->showPlanList();
        }
    }
    
    public function showMainMenu(): void
    {
        $message = LangService::get('admin_product_management_welcome', 'Select a category to manage:');
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📋 مدیریت پلن‌های فروش', 'callback_data' => 'admin_manage_plans']],
                [['text' => '➕ مدیریت بسته‌های حجم', 'callback_data' => 'admin_manage_datapacks']],
                [['text' => '◀️ بازگشت به داشبورد', 'callback_data' => 'admin_dashboard']]
            ]
        ];
        
        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }

    public function showPlanList(): void
    {
        $products = $this->productRepo->findAll();
        $message = LangService::get('admin_plan_list', 'Sales Plans:');
        
        $keyboard = ['inline_keyboard' => []];

        if (!empty($products)) {
            foreach ($products as $product) {
                $label = "{$product['name']} | {$product['panel_name']}";
                $keyboard['inline_keyboard'][] = [
                    ['text' => $label, 'callback_data' => 'noop'],
                    ['text' => '🗑️ حذف', 'callback_data' => 'admin_delete_product_' . $product['id']]
                ];
            }
        }

        $keyboard['inline_keyboard'][] = [['text' => '➕ افزودن پلن جدید', 'callback_data' => 'admin_add_plan_start']];
        $keyboard['inline_keyboard'][] = [['text' => '◀️ بازگشت', 'callback_data' => 'admin_product_menu']];

        $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message, $keyboard);
    }
}