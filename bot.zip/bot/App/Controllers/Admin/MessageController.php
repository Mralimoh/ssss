<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\JobRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class MessageController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private JobRepository $jobRepo;
    private UserRepository $userRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'];
        $this->messageText = $update['message']['text'] ?? null;

        $db = Database::getInstance();
        $this->jobRepo = new JobRepository($db);
        $this->userRepo = new UserRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $admin = $this->userRepo->find($this->chatId);
        $steps = $admin['step'] ?? ['start'];
        $currentStep = end($steps);

        if ($currentStep === 'admin_awaiting_broadcast_message') {
            $this->queueBroadcast();
            array_pop($steps);
            $this->userRepo->updateStep($this->chatId, $steps);
        } else {
            $this->promptForMessage();
        }
    }

    private function promptForMessage(): void
    {
        $admin = $this->userRepo->find($this->chatId);
        $steps = $admin['step'] ?? ['start'];
        $steps[] = 'admin_awaiting_broadcast_message';
        $this->userRepo->updateStep($this->chatId, $steps);

        $message = LangService::get('admin_prompt_for_broadcast', 'Please enter the message to send to all users:');
        $this->telegram->sendMessage($this->chatId, $message);
    }

    private function queueBroadcast(): void
    {
        $payload = json_encode(['text' => $this->messageText]);
        $this->jobRepo->create('broadcast_message', $payload);
        $this->telegram->sendMessage($this->chatId, LangService::get('broadcast_queued_successfully'));
    }
}