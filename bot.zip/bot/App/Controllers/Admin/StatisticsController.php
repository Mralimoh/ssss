<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\StatisticsService;
use App\Services\LangService;
use App\Services\TelegramService;

class StatisticsController
{
    private int $chatId;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->chatId = $update['message']['chat']['id'];
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $statsService = new StatisticsService();
        $stats = $statsService->getStatistics();

        $message = LangService::get('admin_statistics_template', [
            'totalUsers' => $stats['total_users'] ?? 0,
            'activeServices' => $stats['active_services'] ?? 0,
            'totalPanels' => $stats['total_panels'] ?? 0,
        ]);

        $this->telegram->sendMessage($this->chatId, $message);
    }
}