<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\SettingsRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class DashboardController
{
    private int $chatId;
    private SettingsRepository $settingsRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->chatId = $update['message']['chat']['id'];

        $db = Database::getInstance();
        $this->settingsRepo = new SettingsRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $message = LangService::get('admin_dashboard_welcome', "Welcome to the Admin Panel.");

        $keyboard = [
            'keyboard' => [
                [['text' => $this->settingsRepo->get('btn_admin_stats', '📊 آمار ربات')]],
                [
                    ['text' => $this->settingsRepo->get('btn_admin_panels', '🖥️ مدیریت پنل‌ها')],
                    ['text' => $this->settingsRepo->get('btn_admin_products', '🛍️ مدیریت محصولات')]
                ],
                [
                    ['text' => $this->settingsRepo->get('btn_admin_users', '👥 مدیریت کاربران')],
                    ['text' => $this->settingsRepo->get('btn_admin_settings', '⚙️ تنظیمات ربات')]
                ],
                [['text' => $this->settingsRepo->get('btn_admin_messaging', '📨 ارسال پیام')]],
                [['text' => $this->settingsRepo->get('btn_back_to_user_menu', '🏠 بازگشت به منوی کاربری')]]
            ],
            'resize_keyboard' => true
        ];

        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }
}