<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\SettingsRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class SettingsController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private ?string $callbackData;
    private SettingsRepository $settingsRepo;
    private UserRepository $userRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->messageText = $update['message']['text'] ?? null;
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->settingsRepo = new SettingsRepository($db);
        $this->userRepo = new UserRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $user = $this->userRepo->find($this->chatId);
        $steps = $user['step'] ?? ['start'];
        $currentStep = end($steps);

        if ($this->callbackData) {
            $this->handleCallback($steps);
            return;
        }

        if (str_starts_with($currentStep, 'admin_awaiting_setting_')) {
            $this->handleSettingUpdate($currentStep, $steps);
        } else {
            $this->showMainMenu();
        }
    }

    private function handleCallback(array &$steps): void
    {
        $callbackQueryId = $this->update['callback_query']['id'];
        $this->telegram->answerCallbackQuery($callbackQueryId);
        
        if ($this->callbackData === 'admin_settings_texts') {
            $this->showTextSettings();
        } elseif (str_starts_with($this->callbackData, 'admin_edit_setting_')) {
            $keyToEdit = str_replace('admin_edit_setting_', '', $this->callbackData);
            
            array_pop($steps); 
            $steps[] = 'admin_awaiting_setting_' . $keyToEdit;
            $this->userRepo->updateStep($this->chatId, $steps);
            
            $message = LangService::get('admin_prompt_for_new_setting_value', ['key' => $keyToEdit]);
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message, null);
        } else {
             $this->showMainMenu();
        }
    }

    private function handleSettingUpdate(string $currentStep, array &$steps): void
    {
        $keyToUpdate = str_replace('admin_awaiting_setting_', '', $currentStep);
        $newValue = $this->messageText;

        $this->settingsRepo->set($keyToUpdate, $newValue);

        array_pop($steps);
        $this->userRepo->updateStep($this->chatId, $steps);
        
        $this->telegram->sendMessage($this->chatId, LangService::get('admin_setting_updated_successfully'));
    }

    private function showMainMenu(): void
    {
        $message = LangService::get('admin_settings_welcome', 'Select a settings category:');
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📝 متون و دکمه‌ها', 'callback_data' => 'admin_settings_texts']],
                [['text' => '◀️ بازگشت به داشبورد', 'callback_data' => 'admin_dashboard']]
            ]
        ];
        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }

    private function showTextSettings(): void
    {
        $settings = $this->settingsRepo->getAll();
        $message = "Settings for Texts & Buttons:\n";
        $keyboard = ['inline_keyboard' => []];

        $textKeys = ['welcome_message', 'btn_buy_subscription', 'btn_profile', 'btn_support', 'user_profile_template'];

        foreach ($textKeys as $key) {
            $value = htmlspecialchars($settings[$key] ?? 'Not Set');
            $keyboard['inline_keyboard'][] = [
                ['text' => $key, 'callback_data' => 'noop'],
                ['text' => '✏️ Edit', 'callback_data' => "admin_edit_setting_{$key}"]
            ];
        }
        
        $keyboard['inline_keyboard'][] = [['text' => '◀️ بازگشت', 'callback_data' => 'admin_settings_main']];
        
        $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message, $keyboard);
    }
}