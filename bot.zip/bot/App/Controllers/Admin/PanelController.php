<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Repositories\PanelRepository;
use App\Repositories\UserRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class PanelController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private ?string $callbackData;
    private PanelRepository $panelRepo;
    private UserRepository $userRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->messageText = $update['message']['text'] ?? null;
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->panelRepo = new PanelRepository($db);
        $this->userRepo = new UserRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $user = $this->userRepo->find($this->chatId);
        $steps = $user['step'] ?? ['start'];
        $currentStep = end($steps);

        if ($this->callbackData) {
            $this->handleCallback($steps);
            return;
        }

        if (str_starts_with($currentStep, 'admin_add_panel_')) {
            $this->handlePanelCreationSteps($currentStep, $steps);
        } else {
            $this->showPanelList();
        }
    }

    private function handleCallback(array $steps): void
    {
        $callbackQueryId = $this->update['callback_query']['id'];
        $this->telegram->answerCallbackQuery($callbackQueryId);

        if ($this->callbackData === 'admin_add_panel_start') {
            $steps[] = 'admin_add_panel_name';
            $this->userRepo->updateStep($this->chatId, $steps);
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], LangService::get('admin_prompt_panel_name'));
        } elseif (str_starts_with($this->callbackData, 'admin_delete_panel_')) {
            $panelId = (int) str_replace('admin_delete_panel_', '', $this->callbackData);
            $this->panelRepo->delete($panelId);
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], LangService::get('admin_panel_deleted_successfully'));
        }
    }

    private function handlePanelCreationSteps(string $currentStep, array $steps): void
    {

    }

    private function showPanelList(): void
    {
        $panels = $this->panelRepo->findAll();
        $message = LangService::get('admin_panel_management_welcome', 'Manage your VPN panels:');
        
        $keyboard = ['inline_keyboard' => []];

        if (!empty($panels)) {
            foreach ($panels as $panel) {
                $keyboard['inline_keyboard'][] = [
                    ['text' => "{$panel['name']} ({$panel['type']})", 'callback_data' => 'noop'],
                    ['text' => '🗑️ حذف', 'callback_data' => 'admin_delete_panel_' . $panel['id']]
                ];
            }
        }

        $keyboard['inline_keyboard'][] = [['text' => '➕ افزودن پنل جدید', 'callback_data' => 'admin_add_panel_start']];
        $keyboard['inline_keyboard'][] = [['text' => '◀️ بازگشت به داشبورد', 'callback_data' => 'admin_dashboard']];

        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }
}