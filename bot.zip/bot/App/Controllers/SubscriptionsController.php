<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\InvoiceRepository;
use App\Repositories\PanelRepository;
use App\Services\LangService;
use App\Services\TelegramService;
use App\Services\Panels\XuiPanelService;

class SubscriptionsController
{
    private array $update;
    private int $chatId;
    private ?string $callbackData;
    private InvoiceRepository $invoiceRepo;
    private PanelRepository $panelRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->invoiceRepo = new InvoiceRepository($db);
        $this->panelRepo = new PanelRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        if ($this->callbackData) {
            $this->handleCallback();
        } else {
            $this->showSubscriptionsList(1);
        }
    }

    private function handleCallback(): void
    {
        $callbackQueryId = $this->update['callback_query']['id'];
        $this->telegram->answerCallbackQuery($callbackQueryId);

        if (str_starts_with($this->callbackData, 'sub_page_')) {
            $page = (int) str_replace('sub_page_', '', $this->callbackData);
            $this->showSubscriptionsList($page, true);
        } elseif (str_starts_with($this->callbackData, 'manage_service_')) {
            $invoiceId = (int) str_replace('manage_service_', '', $this->callbackData);
            $this->showServiceManagementView($invoiceId);
        }
    }

    private function showSubscriptionsList(int $page, bool $isEdit = false): void
    {
        $limit = 5;
        $invoices = $this->invoiceRepo->findActiveByUser($this->chatId, $page, $limit);
        $totalActive = $this->invoiceRepo->countActiveForUser($this->chatId);

        if ($totalActive === 0) {
            $message = LangService::get('no_active_subscriptions', 'You have no active subscriptions.');
            $isEdit ? $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message, null)
                    : $this->telegram->sendMessage($this->chatId, $message);
            return;
        }

        $message = LangService::get('your_active_subscriptions', 'Your active subscriptions (Page {page}):');
        $message = str_replace('{page}', (string)$page, $message);
        $keyboard = $this->buildSubscriptionListKeyboard($invoices, $page, $limit, $totalActive);

        if ($isEdit) {
            $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $message, $keyboard);
        } else {
            $this->telegram->sendMessage($this->chatId, $message, $keyboard);
        }
    }

    private function showServiceManagementView(int $invoiceId): void
    {
        $invoice = $this->invoiceRepo->findById($invoiceId, $this->chatId);
        if (!$invoice) { return; }

        $panelInfo = $this->panelRepo->findById((int)$invoice['panel_id']);
        if (!$panelInfo) { return; }

        $panelService = new XuiPanelService($panelInfo['api_url'], $panelInfo['username'], $panelInfo['password'], $panelInfo['login_path']);
        $liveData = $panelService->getClient($invoice['panel_service_username']);

        if (!$liveData) {
            $text = LangService::get('service_panel_info_error');
            $keyboard = ['inline_keyboard' => [[['text' => '◀️ بازگشت', 'callback_data' => 'sub_page_1']]]];
        } else {
            $text = LangService::get('service_management_template', [
                'username' => $invoice['panel_service_username'],
                'usage' => sprintf('%.2f / %.2f GB', ($liveData['up'] + $liveData['down']) / (1024**3), $liveData['total'] / (1024**3)),
                'expires' => ($liveData['expiryTime'] > 0) ? date('Y-m-d', $liveData['expiryTime'] / 1000) : 'نامحدود',
            ]);
            
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔄 تمدید سرویس', 'callback_data' => 'renew_service_' . $invoiceId]],
                    [['text' => '➕ خرید حجم اضافه', 'callback_data' => 'add_data_' . $invoiceId]],
                    [['text' => '🔗 دریافت مجدد لینک', 'callback_data' => 'get_link_' . $invoiceId]],
                    [['text' => '◀️ بازگشت به لیست', 'callback_data' => 'sub_page_1']],
                ]
            ];
        }
        
        $this->telegram->editMessageText($this->chatId, $this->update['callback_query']['message']['message_id'], $text, $keyboard);
    }

    private function buildSubscriptionListKeyboard(array $invoices, int $page, int $limit, int $total): array
    {
        $buttons = [];
        foreach ($invoices as $invoice) {
            $buttons[] = [['text' => $invoice['panel_service_username'], 'callback_data' => 'manage_service_' . $invoice['id']]];
        }

        $paginationButtons = [];
        if ($page > 1) {
            $paginationButtons[] = ['text' => '◀️ قبلی', 'callback_data' => 'sub_page_' . ($page - 1)];
        }
        if (($page * $limit) < $total) {
            $paginationButtons[] = ['text' => 'بعدی ▶️', 'callback_data' => 'sub_page_' . ($page + 1)];
        }
        if (!empty($paginationButtons)) {
            $buttons[] = $paginationButtons;
        }

        return ['inline_keyboard' => $buttons];
    }
}