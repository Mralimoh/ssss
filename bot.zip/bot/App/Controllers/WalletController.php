<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Repositories\SettingsRepository;
use App\Repositories\UserRepository;
use App\Repositories\TransactionRepository;
use App\Services\LangService;
use App\Services\TelegramService;

class WalletController
{
    private array $update;
    private int $chatId;
    private ?string $messageText;
    private ?string $callbackData;
    private UserRepository $userRepo;
    private SettingsRepository $settingsRepo;
    private TransactionRepository $transactionRepo;
    private TelegramService $telegram;

    public function __construct(array $update)
    {
        $this->update = $update;
        $this->chatId = $update['message']['chat']['id'] ?? $update['callback_query']['from']['id'];
        $this->messageText = $update['message']['text'] ?? null;
        $this->callbackData = $update['callback_query']['data'] ?? null;

        $db = Database::getInstance();
        $this->userRepo = new UserRepository($db);
        $this->settingsRepo = new SettingsRepository($db);
        $this->transactionRepo = new TransactionRepository($db);
        $this->telegram = new TelegramService($_ENV['BOT_TOKEN']);
    }

    public function handle(): void
    {
        $user = $this->userRepo->find($this->chatId);
        $currentSteps = $user['step'] ?? ['start'];
        $currentStep = end($currentSteps);

        if ($this->callbackData) {
            $this->handleGatewaySelection();
            return;
        }

        if ($currentStep === 'awaiting_deposit_amount') {
            $this->handleAmountEntry();
        } else {
            $this->promptForAmount();
        }
    }

    private function promptForAmount(): void
    {
        $user = $this->userRepo->find($this->chatId);
        $steps = $user['step'] ?? ['start'];
        $steps[] = 'awaiting_deposit_amount';
        $this->userRepo->updateStep($this->chatId, $steps);

        $message = LangService::get('prompt_for_deposit_amount', 'Please enter the amount you wish to deposit (in Tomans):');
        $this->telegram->sendMessage($this->chatId, $message);
    }

    private function handleAmountEntry(): void
    {
        $amount = (float)$this->messageText;
        if ($amount <= 1000) {
            $this->telegram->sendMessage($this->chatId, LangService::get('invalid_amount_min'));
            return;
        }
        
        $user = $this->userRepo->find($this->chatId);
        $steps = $user['step'];
        array_pop($steps);
        $this->userRepo->updateStep($this->chatId, $steps);
        
        $this->showGatewaySelection($amount);
    }

    private function showGatewaySelection(float $amount): void
    {
        $settings = $this->settingsRepo->getAll();
        $keyboard = ['inline_keyboard' => []];
        $message = LangService::get('select_payment_gateway', 'Please select a payment gateway for {amount} Tomans:');
        $message = str_replace('{amount}', number_format($amount), $message);

        if ($settings['payment_gateway_card_transfer_enabled'] ?? false) {
            $keyboard['inline_keyboard'][] = [['text' => '💳 کارت به کارت', 'callback_data' => 'gateway_card_' . $amount]];
        }

        if ($settings['payment_gateway_aqayepardakht_enabled'] ?? false) {
            $keyboard['inline_keyboard'][] = [['text' => '🔵 آقای پرداخت', 'callback_data' => 'gateway_aqayepardakht_' . $amount]];
        }

        if (empty($keyboard['inline_keyboard'])) {
            $this->telegram->sendMessage($this->chatId, LangService::get('no_gateways_available'));
            return;
        }
        
        $keyboard['inline_keyboard'][] = [['text' => '◀️ بازگشت', 'callback_data' => 'back']];

        $this->telegram->sendMessage($this->chatId, $message, $keyboard);
    }
    
    private function handleGatewaySelection(): void
    {
        if (str_starts_with($this->callbackData, 'gateway_card_')) {
            // Further logic for card transfer will be here
        }
    }
}