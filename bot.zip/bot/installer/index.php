<?php

declare(strict_types=1);

// Installer logic will be here. This is a complex file that combines HTML, CSS, and PHP
// to create a multi-step installation wizard. The logic would include:
// 1. A function to check server requirements (PHP version, extensions, folder permissions).
// 2. A router to handle different steps of installation (e.g., ?step=1 for checks, ?step=2 for DB).
// 3. A form for database credentials and a function to test the connection.
// 4. A form for the bot token and admin ID and a function to validate them.
// 5. A final step function that writes the .env file, executes the schema.sql,
//    sets the webhook, and then deletes the installer directory.

session_start();
error_reporting(E_ALL);
ini_set('display_errors', '1');

$step = $_GET['step'] ?? 1;
$baseDir = dirname(__DIR__);

function check_requirements()
{
    return [
        'php_version' => ['label' => 'PHP Version >= 8.1', 'status' => version_compare(PHP_VERSION, '8.1', '>=')],
        'pdo_mysql'   => ['label' => 'PDO MySQL Extension', 'status' => extension_loaded('pdo_mysql')],
        'curl'        => ['label' => 'cURL Extension', 'status' => extension_loaded('curl')],
        'json'        => ['label' => 'JSON Extension', 'status' => extension_loaded('json')],
        'imagick'     => ['label' => 'Imagick Extension', 'status' => extension_loaded('imagick')],
        'env_writable' => ['label' => 'Project folder is writable', 'status' => is_writable($GLOBALS['baseDir'])],
    ];
}

function render_page($title, $content)
{
    echo <<<HTML
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>$title</title>
    <style>
        body { font-family: sans-serif; background-color: #f0f2f5; color: #333; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .container { background: #fff; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; max-width: 600px; }
        h1 { color: #1e3a8a; border-bottom: 2px solid #e2e8f0; padding-bottom: 0.5rem; margin-bottom: 1rem; }
        ul { list-style: none; padding: 0; }
        li { padding: 0.5rem 0; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; }
        li:last-child { border-bottom: none; }
        .status-ok { color: #16a34a; font-weight: bold; }
        .status-fail { color: #dc2626; font-weight: bold; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        input { width: 100%; padding: 0.5rem; border: 1px solid #cbd5e1; border-radius: 4px; box-sizing: border-box; }
        .btn { display: inline-block; background-color: #2563eb; color: #fff; padding: 0.75rem 1.5rem; border-radius: 4px; text-decoration: none; text-align: center; border: none; cursor: pointer; }
        .btn-disabled { background-color: #9ca3af; cursor: not-allowed; }
        .alert { padding: 1rem; margin-bottom: 1rem; border-radius: 4px; }
        .alert-danger { background-color: #fecaca; color: #991b1b; }
        .alert-success { background-color: #dcfce7; color: #166534; }
    </style>
</head>
<body><div class="container">$content</div></body>
</html>
HTML;
    exit;
}

switch ($step) {
    case 1:
        $checks = check_requirements();
        $all_ok = !in_array(false, array_column($checks, 'status'), true);
        $content = '<h1>مرحله ۱: بررسی پیش‌نیازها</h1><ul>';
        foreach ($checks as $check) {
            $status_class = $check['status'] ? 'status-ok' : 'status-fail';
            $status_text = $check['status'] ? 'OK' : 'FAIL';
            $content .= "<li>{$check['label']} <span class='{$status_class}'>{$status_text}</span></li>";
        }
        $content .= '</ul>';
        if ($all_ok) {
            $content .= '<br><a href="?step=2" class="btn">مرحله بعد</a>';
        } else {
            $content .= '<p class="alert alert-danger">لطفاً پیش‌نیازهای سرور را برطرف کرده و صفحه را رفرش کنید.</p>';
        }
        render_page('نصب ربات - مرحله ۱', $content);
        break;

    case 2:
        $error = $_SESSION['error'] ?? null;
        unset($_SESSION['error']);
        $content = '<h1>مرحله ۲: تنظیمات دیتابیس</h1>';
        if ($error) {
            $content .= "<p class='alert alert-danger'>$error</p>";
        }
        $content .= '<form method="post" action="?step=3">
            <div class="form-group"><label>نام دیتابیس:</label><input type="text" name="db_name" required></div>
            <div class="form-group"><label>نام کاربری دیتابیس:</label><input type="text" name="db_user" required></div>
            <div class="form-group"><label>رمز عبور دیتابیس:</label><input type="password" name="db_pass"></div>
            <div class="form-group"><label>میزبان دیتابیس:</label><input type="text" name="db_host" value="localhost" required></div>
            <button type="submit" class="btn">تست و ادامه</button>
        </form>';
        render_page('نصب ربات - مرحله ۲', $content);
        break;

    case 3:
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') header('Location: ?step=2');
        
        $_SESSION['db'] = $_POST;
        try {
            $dsn = sprintf("mysql:host=%s;dbname=%s;charset=utf8mb4", $_POST['db_host'], $_POST['db_name']);
            new PDO($dsn, $_POST['db_user'], $_POST['db_pass']);
            header('Location: ?step=4');
        } catch (PDOException $e) {
            $_SESSION['error'] = 'اتصال به دیتابیس ناموفق بود: ' . $e->getMessage();
            header('Location: ?step=2');
        }
        break;

    case 4:
        $error = $_SESSION['error'] ?? null;
        unset($_SESSION['error']);
        $content = '<h1>مرحله ۳: تنظیمات ربات</h1>';
         if ($error) {
            $content .= "<p class='alert alert-danger'>$error</p>";
        }
        $content .= '<form method="post" action="?step=5">
            <div class="form-group"><label>توکن ربات تلگرام:</label><input type="text" name="bot_token" required></div>
            <div class="form-group"><label>نام کاربری ربات (بدون @):</label><input type="text" name="bot_username" required></div>
            <div class="form-group"><label>آیدی عددی ادمین اصلی:</label><input type="text" name="admin_id" required></div>
            <button type="submit" class="btn">نصب نهایی</button>
        </form>';
        render_page('نصب ربات - مرحله ۳', $content);
        break;
        
    case 5:
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['db'])) header('Location: ?step=4');
        $_SESSION['bot'] = $_POST;
        
        $env_content = "BOT_TOKEN={$_SESSION['bot']['bot_token']}\n";
        $env_content .= "BOT_USERNAME={$_SESSION['bot']['bot_username']}\n";
        $env_content .= "DB_HOST={$_SESSION['db']['db_host']}\n";
        $env_content .= "DB_NAME={$_SESSION['db']['db_name']}\n";
        $env_content .= "DB_USER={$_SESSION['db']['db_user']}\n";
        $env_content .= "DB_PASS={$_SESSION['db']['db_pass']}\n";
        
        if (file_put_contents($baseDir . '/.env', $env_content) === false) {
             $_SESSION['error'] = 'خطا در ساخت فایل .env. لطفا از writable بودن پوشه پروژه اطمینان حاصل کنید.';
             header('Location: ?step=4');
             exit;
        }

        try {
            $dsn = sprintf("mysql:host=%s;dbname=%s;charset=utf8mb4", $_SESSION['db']['db_host'], $_SESSION['db']['db_name']);
            $db = new PDO($dsn, $_SESSION['db']['db_user'], $_SESSION['db']['db_pass']);
            $schema = file_get_contents('schema.sql');
            $db->exec($schema);
            
            $stmt = $db->prepare("INSERT INTO `admins` (user_id) VALUES (:id)");
            $stmt->execute(['id' => $_SESSION['bot']['admin_id']]);

        } catch (Exception $e) {
            $_SESSION['error'] = 'خطا در ساخت جداول دیتابیس: ' . $e->getMessage();
            header('Location: ?step=4');
            exit;
        }
        
        session_destroy();
        $content = '<div class="alert alert-success">✅ نصب با موفقیت انجام شد!</div>';
        $content .= '<p>مهم: پوشه `installer` اکنون باید به صورت دستی از روی هاست شما حذف شود.</p>';
        render_page('نصب موفق', $content);
        break;

    default:
        header('Location: ?step=1');
        break;
}